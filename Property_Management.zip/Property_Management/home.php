<?php 
session_start();

if(!isset($_SESSION['email'])){
    header('Location: index.php');
}

if (isset($_SESSION['id']) && isset($_SESSION['email'])) {

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="home-header">
    <a href="logout.php" class="logout-link">Logout</a>
    <h1 class="web-logo">Indian Housing</h1>
    <h1 class="hello-user">Welcome <?php echo $_SESSION['name']; ?></h1> <br>
    </div>
    <hr>
    <div class="home-container">
    <div class="add-property">
        <h2>Add Property</h2>
        <a href="add-property.php" class="add-link">Click to Add property</a>
    </div>
        <hr>
        <div class="property-list">
            <h2>See Your Property List</h2>
            <a href="property-list.php" class="property-link">Click here to display property list</a>
        </div>
    </div>

</body>
</html>
<?php 
}

else{
     header("Location: index.php");
     exit();
}
 ?>









<!-- Property List -->


<?php
include('connection.php'); 


//print_r($_SESSION['id']);die;

if(!isset($_SESSION['id'])){
    header('Location: home.php');
}
if (isset($_SESSION['id']) && isset($_SESSION['email'])) {
    //print_r($_SESSION['id']);die;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property list</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php 

      if (isset($_GET["delete_id"]))
      {
        $id= $_GET['delete_id'];

      $sql = "DELETE FROM `users_details` WHERE pid=$id";
      $row=mysqli_query($conn,$sql);
      if($row){
        echo "<script> Record deleted successfully.</script>";
        
      }
      else{
        echo "<script>Record is not Deleted.</script>";
      }
      
      }

    $id= $_SESSION['id'];
     //print_r($_SESSION['id']);die;
     $result = mysqli_query($conn,"SELECT * FROM `users_details` WHERE id=$id");
   
    $counter = 0;

  
    ?>

     
    <div class="list-container">

    <table class="list-tbl">

 
        <tr>
            <th>S.No.</th>
            <th>Rent/Sale</th>
            <th>Location</th>
            <th>Bed</th>
            <th>Bath</th>
            <th>Value</th>
            <th>Property Images</th>
        </tr>
 
        <?php

       while($row = mysqli_fetch_assoc($result))
       {
        
           ?>
    
        <tr>
            <td><?php echo ++$counter; ?></td>
            <td><?php echo $row['propertyfor'] ?></td>
            <td><?php echo $row['location'] ?> </td>
            <td><?php echo $row['bed'] ?></td>
            <td><?php echo $row['bath'] ?></td>
            <td><h3>₹</h3><?php echo $row['price'] ?></td>
            <td><img height="50px" width="60px" src="<?php echo $row['prop_images'];?>"  ></td>
            

        </tr>
        
        <?php
			}

        
			?>
      
      
    </table>   
    <br>  

</body>
</html>

<?php
    
}
else{
    header("Location: index.php");
    exit();
}
?>

<script LANGUAGE="JavaScript">

function checkdelete()
{
  return confirm('Are you sure to delete this record?');
}

</script>