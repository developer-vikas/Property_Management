<?php

$host ='localhost';
$username= 'root';
$password='';
$db_name= 'property_management';

$conn = mysqli_connect($host,$username,$password,$db_name);

if(!$conn)
{
    echo "Database not connected";
}
else
{
    //echo "Connected";
}

?>