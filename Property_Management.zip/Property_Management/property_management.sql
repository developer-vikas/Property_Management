-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2022 at 02:28 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `property_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_details`
--

CREATE TABLE `account_details` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account_details`
--

INSERT INTO `account_details` (`id`, `name`, `mobile`, `email`, `password`) VALUES
(1, 'Vikas Yadav', 8358883274, 'vikas@radtech.pro', '827ccb0eea8a706c4c34a16891f84e7b'),
(3, 'Stacy Dorsey', 1234567876, 'peluhujy@mailinator.com', 'f3ed11bbdb94fd9ebdefbaf646ab94d3'),
(4, 'Judith Chan', 7648739937, 'kobolizepi@mailinator.com', 'f3ed11bbdb94fd9ebdefbaf646ab94d3'),
(5, 'Chloe Haynes', 5467387338, 'mawacoqupy@mailinator.com', 'f3ed11bbdb94fd9ebdefbaf646ab94d3'),
(6, 'Yuli Wiggins', 6784983399, 'syty@mailinator.com', '827ccb0eea8a706c4c34a16891f84e7b'),
(7, 'Tad Fletcher', 7487789333, 'soxal@mailinator.com', 'f3ed11bbdb94fd9ebdefbaf646ab94d3'),
(8, 'Ayush', 6789399301, 'ayush@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `users_details`
--

CREATE TABLE `users_details` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `propertyfor` varchar(100) NOT NULL,
  `location` varchar(250) NOT NULL,
  `bed` int(50) NOT NULL,
  `bath` int(50) NOT NULL,
  `prop_images` varchar(255) NOT NULL,
  `price` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_details`
--

INSERT INTO `users_details` (`id`, `pid`, `propertyfor`, `location`, `bed`, `bath`, `prop_images`, `price`) VALUES
(1, 5, 'Rent', 'Illo et aut et velit', 1, 3, 'uploads/972bb015f76ff7a8d78150bb9bb5f18b.jpg', 93344),
(1, 7, 'Sale', 'Ea temporibus distin', 4, 2, 'uploads/0c3333fedf1ce3437e1589e20f093ddf.jpg48d9ce84e241d205c3665f41b5aa68ed.jpg', 873),
(1, 8, 'Sale', 'Irure iste enim quia', 1, 7, 'uploads/9711ca4e4c7b71c1fc5054d8c7ee1401.jpg', 422),
(1, 9, 'Rent', 'In ut exercitation n', 5, 1, 'uploads/1b696bf123e0f9966dd5557643e421cd.png', 703),
(1, 10, 'Sale', 'Aspernatur quo dolor', 9, 10, 'uploads/0ba2431780d41940f5c0a64ef3d65e38.jpg', 241),
(1, 11, 'Sale', 'Aspernatur quo dolor', 9, 10, 'uploads/396847609740b14ff790557a83521b60.jpg', 241),
(1, 12, 'Sale', 'At doloremque facili', 8, 6, 'uploads/546b6d78b9459edd5c535dca344ade23.jpg', 629),
(1, 13, 'Sale', 'Odit est soluta arch', 8, 2, 'uploads/f500961d8a1c123d9fe3126051828f15.jpg', 217),
(1, 14, 'Rent', 'Dolorem quis aut off', 5, 2, 'uploads/b9a384e547e3a14d5b893b0ba2e16b01.jpg', 386),
(1, 15, 'Sale', 'Quasi officiis sint ', 2, 6, 'uploads/d7c4f913137293704524ddc186d4c99f.jpg', 96),
(8, 16, 'Rent', 'Totam nulla dolorum ', 4, 6, 'uploads/870bf3ecfb48d6fc56436175ec1fab2f.jpg61532b473e456b68ae585342732a8a2c.jpg8be599fecb4786df7ec23adfe4be453b.jpg', 414),
(6, 17, 'Rent', 'india', 2, 10, 'uploads/5d6d1c21508d8331387e814cd50c3293.phpac383b6917b8dadd3ca84f449ad956f1.phpc8d0a32fa653e377ff9337902b4e9bf1.phpe3838539f8bfcbcb7ea8411955beaf4d.php', 1234),
(6, 18, 'Rent', 'india', 2, 10, 'uploads/dbdf835b42369c0de1ce89a9955b0bd8.php', 1234),
(1, 19, 'Rent', 'Itaque quos eiusmod ', 1, 5, 'uploads/56f2418967415e801dc79c0bab2f8e9f.jpg', 944),
(1, 20, 'Rent', 'Quam iste quidem vol', 10, 6, 'uploads/3ab1eff1b622325c874034320cab1f43.jpg', 895),
(1, 21, 'Sale', 'Dolor repellendus V', 10, 10, 'uploads/4378923dd5c663699bf4da0dd2ae8e76.jpg', 39),
(1, 22, 'Rent', 'Quia neque anim fugi', 5, 9, 'uploads/d10719027e63f6ca4c094b03d2e06381.jpg', 666),
(1, 23, 'Rent', 'Non iure ex et volup', 3, 9, 'uploads/cf98457d9c9adb6b378598857342e963.jpg', 719),
(1, 24, 'Rent', 'Dicta libero sit vo', 10, 7, 'uploads/8f9b007e50ff4035ec12286856b4313b.jpg', 107),
(1, 25, 'Sale', 'Cum error non quia d', 3, 5, 'uploads/9cfd594424d754f25051cb303969bcb2.jpg', 150),
(1, 26, 'Rent', 'Nihil non et volupta', 1, 3, 'uploads/eee76a1896f49234a6766dbd61603517.jpg', 263),
(1, 27, 'Sale', 'Cupidatat error ex s', 5, 1, 'uploads/8b5a32b1eff939070f315789bf85e211.jpg', 514),
(1, 67, 'Sale', 'Eaque atque dolores ', 2, 3, 'uploads/4b374e45b55cdf5d7b69c2559bf44c6c.jpg', 627),
(1, 68, 'Sale', 'Doloremque voluptate', 1, 4, 'uploads/68b2eee83915bb0ad989195ae47d1a5f.jpg', 474),
(1, 69, 'Sale', 'Velit non reprehende', 2, 8, 'uploads/dee7aeea4879e9eddef0ef192eb4738b.jpg', 540),
(1, 70, 'Sale', 'Vero veniam velit c', 9, 6, 'uploads/2f1cf51c909f913d2ff641d5dbcd4634.jpg', 24),
(8, 71, 'Sale', 'Molestiae consequatu', 3, 3, 'uploads/ea4f2dbb9c576e745eadf2552049afb9.jpg', 915),
(8, 72, 'Sale', 'Aliquam dolore magni', 5, 9, 'uploads/cca2b4036a224b69b7f9c194e30568b7.jpg', 554),
(8, 73, 'Sale', 'Eiusmod vel eveniet', 1, 7, 'uploads/e176982ef75875b6dc38005279aa31ad.jpg', 259),
(8, 74, 'Sale', 'Sint earum officia ', 5, 10, 'uploads/2380f9e75c7744c295d90528877f71ed.jpg', 63),
(8, 75, 'Sale', 'Laboriosam deserunt', 6, 10, '', 903),
(8, 76, 'Rent', 'Assumenda fugiat la', 9, 2, 'uploads/3e892531fab95daca1c6a041d2008a91.jpg', 755),
(8, 77, 'Sale', 'Similique laudantium', 8, 5, 'uploads/a42c688541dafc04e98c05819da7134a.jpg', 345),
(8, 78, 'Rent', 'Ipsam tempor cillum ', 4, 7, 'uploads/31945cb641190f88e257c05eb7979f31.jpg', 620),
(8, 79, 'Sale', 'Id sapiente aliqua ', 5, 6, 'uploads/01f8879204ab38e49953b7628f4cb7cc.jpg294aa71271c124492070c65031940277.jpg', 673),
(8, 80, 'Sale', 'Sed sapiente sint q', 6, 7, 'uploads/bb98a6e5dd575f58d65788097c60ebe4.jpg', 834);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_details`
--
ALTER TABLE `account_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_details`
--
ALTER TABLE `users_details`
  ADD PRIMARY KEY (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_details`
--
ALTER TABLE `account_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users_details`
--
ALTER TABLE `users_details`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
