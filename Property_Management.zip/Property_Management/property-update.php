<?php 
    
     include('connection.php');
   
    //echo $_GET['pid'];

    $prop_err=$loc_err=$bed_err=$bath_err=$price_err=$price_val="";

    if (isset($_POST["edit"]))
     {

$j = 0;     
$target_path = "uploads/";     
for ($i = 0; $i < count($_FILES['file']['name']); $i++) {

$validextensions = array("jpeg", "jpg", "png");      
$ext = explode('.', basename($_FILES['file']['name'][$i]));   
$file_extension = end($ext); 
$target_path = $target_path . md5(uniqid()) . "." . $ext[count($ext) - 1];     
$j = $j + 1;      
if (($_FILES["file"]["size"][$i] < 1000000)     // Approx. 1mb files can be uploaded.
&& in_array($file_extension, $validextensions)) {
if (move_uploaded_file($_FILES['file']['tmp_name'][$i], $target_path)) {

echo $j. ').<span class="success">Image uploaded successfully!.</span><br/><br/>' ;
} else {     
echo $j. ').<span class="error">please try again!.</span><br/><br/>';
}
} else {    
echo $j. ').<span class="error">***Image size must be less than 1mb and only jpeg, jpg, png files are allowed.***</span><br/><br/>';
}
}


      
     $id= $_GET['pid'];
     $propertyfor = $_POST['propertyfor'];
     $location = $_POST['location'];
     $bed = $_POST['bed'];
     $bath = $_POST['bath'];
     $price = $_POST['price'];


     if (empty($propertyfor)) {

        $prop_err= "<span class='error'>Select property is for rent or sale.</span>";
     }
     else if(empty($location))
     {
         $loc_err ="<span class='error'>Enter property location.</span>";
     }
     else if(empty($bed))
     {
        $bed_err="<span class='error'>Select no. of bed.</span>";
     }
     else if(empty($bath))
     {
        $bath_err="<span class='error'>Select no. of bed.</span>";
     }
     else if(empty($price))
     {
        $price_err="<span class='error'>Select no. of bed.</span>";
     }
     else if(!preg_match('/^[0-9]+$/', $price)) {
        $price_val="<span class='error'>Mobile number should be number only with exact 10 digit. </span>";
    }
     else{
     
     $sql="UPDATE `users_details` SET `propertyfor`='$propertyfor',
     `location`='$location',`bed`='$bed',`bath`='$bath',`prop_images`='$target_path',
     `price`='$price' WHERE  pid=$id ";
     $row=mysqli_query($conn,$sql);
     if($row)
     {
     
        header('location:property-list.php');
     } 

     else
     {
         echo "<script>alert('Unknown error occured try after sometimes.')</script>";
     }
    
    }

    }

    $id= $_GET['pid'];
    $result = mysqli_query($conn,"SELECT * FROM `users_details` WHERE pid=$id");
    $row1 = mysqli_fetch_array($result);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update property</title>
    <link rel="stylesheet" href="style.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="script.js"></script>
</head>
<body class="edit-property-body">
<div class="update-container">
    <form action="" method="post" name="upd-prop-form" enctype="multipart/form-data" class="update-property-form">
    <a href="property-list.php" class="property-list-link">Back to property list</a> <br>
    <h2>Update property details</h2>
    
    <div>
    <label class="update-prop-label">Property For:</label><br>
    <select name="propertyfor" id="" class="update-property-select">
        <option value="<?php echo $row1['propertyfor']; ?>" selected><?php echo $row1['propertyfor']; ?></option>
        <option value="Rent">Rent</option>
        <option value="Sale">Sale</option>
    </select>
    <?php echo $prop_err; ?>
    </div>

    <div>
    <label class="update-prop-label">Location</label> <br>
    <textarea name="location" class="update-location" id="" cols="30" rows="10"><?php echo $row1['location']; ?></textarea>
     <?php echo $loc_err; ?>    
    </div>
    
    <div>
        <label class="update-prop-label">Bed</label><br>
            <select name="bed" id=""  class="update-property-select">
                <option value="<?php echo $row1['bed']; ?>" selected><?php echo $row1['bed']; ?></option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>
            <?php echo $bed_err; ?>
    </div>

    <div>
        <label class="update-prop-label">Bath</label><br>
            <select name="bath" id="" class="update-property-select">
                <option value="<?php echo $row1['bath']; ?>" selected><?php echo $row1['bath']; ?></option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>
            <?php echo $bath_err; ?>
    </div>

    <div>
        <label  class="update-prop-label">Price</label><br>
        <input type="text" name="price" class="update-propertyinput" value="<?php echo $row1['price']; ?>">
        <?php 
        echo $price_err;
        echo $price_val;
        ?>
    </div>

    <div>
        <label  class="update-prop-label">Property Images</label> <br>
        <div id="filediv"><input type="file" name="file[]" id="file" class="add-images" required></div>
        <img height="50px" width="60px" src="<?php echo $row1['prop_images'];?>"  >
        <input type="button" id="add_more" class="btn-up" value="Add More Images"/><br>
    </div>

    <div>
    <input type="submit" name="edit" value="Update" class="btn-success"  >
    </div>
    
</body>
</html>







<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

<script type="text/javascript">
$(function () {
    
$("form[name='upd-prop-form']").validate({
// Define validation rules
rules: {

propertyfor: "required",
location: "required",
bed: "required",
bath: "required",
files: "required",
price: "required",


propertyfor: {
    required: true,
},
location: {
    required: true,
},
bed: {
    required: true,
},
bath: {
    required: true,
},
files: {
    required: true,
},
price: {
    required: true,
    number: true,
}




},
// Specify validation error messages
messages: {


propertyfor: {
    required: "Please select property type",
},
location: {
    required: "Please enter property location",
},
bed: {
    required: "Please enter no. of bed",
},
bath: {
    required: "Please enter no. of bath",
},
files: {
    required: "Please upload property images",
},
price: {
    required: "Please enter price of property",
    number: "Only numeric values are allowed",
}

},
submitHandler: function (form) {
form.submit();
}
});
}); 

 

</script>