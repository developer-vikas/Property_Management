<?php 
session_start(); 
include ('connection.php');

$log_err=$log_err1="";

if(isset($_POST['login'])){

if (isset($_POST['email']) && isset($_POST['password'])) {

	//echo "helloooo" or die();

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$email = validate($_POST['email']);
	$pass = validate($_POST['password']);

	if (empty($email)) {
		header("Location: index.php");
	    exit();
	}else if(empty($pass)){
        header("Location: index.php");
	    exit();
	}
	else{

		//Hashing the password
        $pass = md5($pass);

		$sql = "SELECT * FROM `account_details` WHERE email='$email' AND password='$pass'";

		//echo $sql; die();

		$result = mysqli_query($conn, $sql);
        //echo 7849;die();
        

		if (mysqli_num_rows($result) === 1) {
            // echo 7848;die();
             $row = mysqli_fetch_assoc($result);
             //echo 4389;die();
             if ($row['email'] === $email && $row['password'] === $pass) {
                 $_SESSION['name'] = $row['name'];
                 $_SESSION['id'] = $row['id'];
                 $_SESSION['email'] = $row['email'];
                 $_SESSION['mobile'] = $row['mobile'];
                 header("Location: home.php");
                 exit();
             }
             else{
                 $log_err = "<span class='error'>Email and password didn't match.</span>";
                 
                 }
         }
         else{
             //echo "hello";
             $log_err1 = "<span class='error'>Email and password didn't match.</span>";
         }
	}
	
}else{
	header("Location: index.php");
	exit();
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Management</title>
    <link rel="stylesheet" href="style.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
</head>
<body class="index-body-content">
    <div class="index-container">
        <form action="" method="post" name="login-form" class="login-form">
            <h1>Account Login</h1>
            <?php echo $log_err;
                  echo $log_err1;
            ?>
            <div>
            <label class="index-label">E-Mail</label><br>
            <input type="email" name="email" id="email" placeholder="Enter e-mail id" class="index-input">
            </div>

            <div>
                <label class="index-label">Password</label><br>
                <input type="password" name="password" id="password" placeholder="Enter password" class="index-input">
            </div>

            <a href="signup.php" class="signup-link">Create an account.</a>

            <input type="submit" id="submit" name="login" value="Login" class="btn-success">

        </form>
    </div>
    
</body>
</html>




<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

<script>

$(function () {
    
$("form[name='login-form']").validate({
// Define validation rules
rules: {

email: "required",
password: "required",


email: {
required: true,
email: true
},
password: {
required: true
},


},
// Specify validation error messages
messages: {

email: {
required: "Please enter your email",
email: "Please enter a valid email address"
},
password: {
required: "Please enter password.",
},

},
submitHandler: function (form) {
form.submit();
}
});
}); 

 

</script>



