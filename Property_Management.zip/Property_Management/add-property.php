<?php 

session_start();
$success=$error_ukn=$pro_err=$loc_err=$bed_err=$bath_err=$img_err="";
if(!isset($_SESSION['email'])){
    header('Location: index.php');
}

if (isset($_SESSION['id']) && isset($_SESSION['email'])) {

   // print_r($_SESSION['id']); die;

 ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Proprty</title>
    <link rel="stylesheet" href="style.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <script src="script.js"></script>
</head>
<body class="add-property-body">
    <div class="add-container">
        <form action="" method="post" name="add-properties-form" id="myform" enctype="multipart/form-data" class="add-property-form">
            <h2>Add your property</h2>
            <?php echo $success; ?>
            <div>
                
                <input type="hidden" name="id" value="<?php echo $_SESSION['id']; ?>">
                <label class="add-property-label">Property for</label><br>
                <select name="propertyfor" id="" class="add-property-select">
                <option value="">---Select Property Type---</option>
                <option value="Rent">Rent</option>
                <option value="Sale">Sale</option>
            </select><br>

            
        <div>
            <label class="add-property-label">Location</label><br>
            <textarea name="location" id="" cols="30" rows="5" class="add-location" placeholder="Enter property location"></textarea>

        </div>

        <div>
            <label class="add-property-label">Bed</label><br>
            <select name="bed" id="" class="add-property-select">
                <option value="">--Select Bed--</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>
        </div>

        <div>
            <label class="add-property-label">Bath</label><br>
            <select name="bath" id="" class="add-property-select">
                <option value="">--Select Bath--</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>
        </div>

        <div>
            <label class="add-property-label">Upload Property Images</label> <br>
            <div id="filediv"><input type="file" name="file[]" id="file" class="add-images" required/></div>
            <input type="button" id="add_more" class="btn-up" value="Add More Images"/><br>

        </div>

        <div>
            <label class="add-property-label">Price</label><br>
            <input type="text" name="price" class="add-property-input">
        </div> <br>

        

        <input type="submit" name="submit" id="submit" value="Add Property" class="btn-success">

        <br><br>
         <a href="home.php">Back to homepage</a>

        </div>
        </form>
        
    </div>
</body>
</html>
<?php 
}

else{
     header("Location: index.php");
     exit();
}
?>











<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

<script type="text/javascript">
$(document).ready(function (e){
    //alert('Hello');
$("#myform").on('submit',(function(e){ 
e.preventDefault();
//alert('hey');
var formdata = new FormData(this);
$.ajax({
url: "prop-details.php",
type: "POST",
data: formdata,
contentType: false, 
cache: false, 
processData:false,
success: function(data){
    //alert(data);
alert("Data inserted successfully");
$('#myform').trigger('reset');
},
error: function(data){
    alert("Failed to insert data.");
}
});
}));
});









$(function () {
    
$("form[name='add-properties-form']").validate({
// Define validation rules
rules: {

propertyfor: "required",
location: "required",
bed: "required",
bath: "required",
files: "required",
price: "required",


propertyfor: {
    required: true,
},
location: {
    required: true,
},
bed: {
    required: true,
},
bath: {
    required: true,
},
files: {
    required: true,
},
price: {
    required: true,
    number: true,
}




},
// Specify validation error messages
messages: {


propertyfor: {
    required: "Please select property type",
},
location: {
    required: "Please enter property location",
},
bed: {
    required: "Please enter no. of bed",
},
bath: {
    required: "Please enter no. of bath",
},
files: {
    required: "Please upload property images",
},
price: {
    required: "Please enter price of property",
    number: "Only numeric values are allowed",
}

},
submitHandler: function (form) {
form.submit();
}
});
}); 

 

</script>