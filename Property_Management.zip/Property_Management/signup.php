<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="signup-body">




<?php
     include('connection.php');

     $name_err="";
     $name_val="";
     $mob_err="";
     $mob_err1="";
     $mob_val="";
     $mail_err="";
     $mail_err1="";
     $mail_val="";
     $pass_err="";
     $re_pass_err="";
     $pass_val="";
     $success="";
     $error_ukn="";
     

     
     

     if (isset($_POST["submit"])){
        //echo "helloooo";die();

  
     if (!empty($_POST)){


        //echo welcome;die;

    
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $pass = $_POST['password'];
	$re_pass = $_POST['re_password'];
    


	if(empty($name)){
        $name_err=  "<span class='error'>Please enter your name.</span>";
        
    }
    else if(!preg_match("/^[a-zA-Z ]*$/", $name)) {
        $name_val=  "<span class='error'>Only alphabet and whitespace are allowed.</span>";
    }
    else if(empty($email)){
        $mail_err="<span class='error'>Please Enter Email-Id.</span>";
    }
    else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $mail_val="<span class='error'>Please Enter valid Email.</span>";
    }
    else if(empty($mobile)){
        $mob_err="<span class='error'>Please Enter Mobile Number.</span>";   
    }
    else if(!preg_match('/^[0-9]{10}+$/', $mobile)) {
        $mob_val="<span class='error'>Mobile number should be number only with exact 10 digit. </span>";
    }
    else if(empty($pass)){
        $pass_err="<span class='error'>Please Enter Password</span>";
        
	}
    else if(empty($re_pass)){
        $re_pass_err="<span class='error'>Please Enter Confirm Password</span>";
    }
    else if($pass!== $re_pass){
        $pass_val="<span class='error'>Passord didn't Match.</span>";
        
    }    
    else{

        //echo 'hello';die;

        

        //Hashing the password
        $pass = md5($pass);

        $sql1 = "SELECT * FROM account_details WHERE email='$email' ";
        $sql3 = "SELECT * FROM account_details WHERE mobile='$mobile' ";

        $result1 = mysqli_query($conn, $sql1) ;
        $result3 = mysqli_query($conn, $sql3) ;

        //echo "hiiiii"; die;

		
        if (mysqli_num_rows($result1) > 0){
            // echo "hiiiii" ;die;
            $mail_err1= "<span class=error> This email-id is already used.</span>";
             
         }
        else if (mysqli_num_rows($result3) > 0){
            // echo "hiiiii" ;die;
             $mob_err1= "<span class=error>This mobile number is already used.</span>";
         }
        else{
           //echo "Welcome" ;die();
           $sql2 = "INSERT INTO `account_details`(`id`, `name`, `mobile`, `email`, `password`)
            VALUES ('','$name','$mobile','$email','$pass')";


           $result2 = mysqli_query($conn, $sql2);
           if($result2){
               $success="<span class='success'>Your account is created successfully.</span>";
           }
           else{
            $error_ukn="<span class='error'>Unknown error occurred please try again.</span>";
            
           }
        }
			
	}
    
	
}else{
	header("Location: signup.php");
	exit();
}
}
?>












<div class="signup-container">
    <form action="" method="post" name="signup" class="signup-form">
        <h1>Signup for better experience.</h1>
        <?php 
                echo $success;
                echo $pass_val;
                echo $error_ukn;
             ?>
        <div>
            <label class="signup-label">Full name</label> <br>
            <input type="text" name="name" id="" placeholder="Enter your full name" class="signup-input">
            <?php 
                echo $name_err;
                echo $name_val;
             ?>
        </div>

        <div>
            <label class="signup-label">Mobile</label> <br>
            <input type="text" name="mobile" id="" placeholder="Enter mobile number" class="signup-input">
            <?php 
                echo $mob_err;
                echo $mob_err1;
                echo $mob_val;
             ?>
        </div>

        <div>
            <label class="signup-label">E-mail</label> <br>
            <input type="email" name="email" id="" placeholder="Enter your e-mail id" class="signup-input">
            <?php 
                echo $mail_err;
                echo $mail_err1;
                echo $mail_val;
             ?>
        </div>

        <div>
            <label class="signup-label">Password</label> <br>
            <input type="password" name="password" id="password" placeholder="Enter password" class="signup-input">
            <?php 
                echo $pass_err;
                
             ?>
        </div>

        <div>
            <label class="signup-label">Confirm Password</label> <br>
            <input type="password" name="re_password" id="" placeholder="Confirm password" class="signup-input">
            <?php 
                echo $re_pass_err;
             ?>
        </div>
        <div>
            <input type="submit" name="submit" value="Signup" class="btn-up">
        </div>
        <p>Already have an account?<a href="index.php">Click to Login</a></p>
    </form>
</div>
    
</body>
</html>


<!-- JavaScript -->

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

<script>
$(function () {
    
$("form[name='signup']").validate({
// Define validation rules
rules: {
name: "required",
email: "required",
mobile: "required",
password: "required",
re_password: "required",

name: {
 required: true,

},
mobile: {
required: true,
minlength: 10,
maxlength: 10,
number: true
},
email: {
required: true,
email: true
},
password: {
required: true
},
re_password: {
required: true,
equalTo: "#password"   
}

},
// Specify validation error messages
messages: {
name: {
   required: "Please enter name.",
   
},
mobile: {
required: "Please provide a phone number",
minlength: "Phone number must be 10 digit",
maxlength: "Phone number must 10 digit"
},
email: {
required: "Please enter your email",
email: "Please enter a valid email address"
},
password: {
required: "Please enter password.",
},
re_password: {
required: "Please confirm password.",
equalTo : "Your password didn't match."
}
},
submitHandler: function (form) {
form.submit();
}
});
}); 

 

</script>
