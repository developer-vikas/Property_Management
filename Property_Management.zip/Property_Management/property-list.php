<!-- <h1>hello</h1> -->

<?php
include('connection.php'); 
session_start();

//print_r($_SESSION['id']);die;

if(!isset($_SESSION['id'])){
    header('Location: home.php');
}
if (isset($_SESSION['id']) && isset($_SESSION['email'])) {
    //print_r($_SESSION['id']);die;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property list</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php 

      if (isset($_GET["delete_id"]))
      {
        $id= $_GET['delete_id'];

      $sql = "DELETE FROM `users_details` WHERE pid=$id";
      $row=mysqli_query($conn,$sql);
      if($row){
        echo "<script> Record deleted successfully.</script>";
        
      }
      else{
        echo "<script>Record is not Deleted.</script>";
      }
      
      }

    $id= $_SESSION['id'];
     //print_r($_SESSION['id']);die;
     $result = mysqli_query($conn,"SELECT * FROM `users_details` WHERE id=$id");
   
    $counter = 0;





    //define total number of results you want per page  
    $results_per_page = 3;  
  
    //find the total number of results stored in the database  
    $query = "select *from users_details";  
    $result1 = mysqli_query($conn, $query);  
    $number_of_result = mysqli_num_rows($result1);  
  
    //determine the total number of pages available  
    $number_of_page = ceil ($number_of_result / $results_per_page);  
  
    //determine which page number visitor is currently on  
    if (!isset ($_GET['page']) ) {  
        $page = 1;  
    } else {  
        $page = $_GET['page'];  
    }  
  
    //determine the sql LIMIT starting number for the results on the displaying page  
    $page_first_result = ($page-1) * $results_per_page;  
  
    //retrieve the selected results from database   
    $query = "SELECT *FROM users_details LIMIT " . $page_first_result . ',' . $results_per_page;  
    $result = mysqli_query($conn, $query);




  
    ?>

 

     <a href="home.php" class="home-link">Back to home</a>
     
    <div class="list-container">

    <table class="list-tbl">

 
        <tr>
            <th>S.No.</th>
            <th>Rent/Sale</th>
            <th>Location</th>
            <th>Bed</th>
            <th>Bath</th>
            <th>Value</th>
            <th>Property Images</th>
            <th colspan="2">Action</th>
        </tr>
 
        <?php

       while($row = mysqli_fetch_assoc($result))
       {
        
           ?>
    
        <tr>
            <td><?php echo ++$counter; ?></td>
            <td><?php echo $row['propertyfor'] ?></td>
            <td><?php echo $row['location'] ?> </td>
            <td><?php echo $row['bed'] ?></td>
            <td><?php echo $row['bath'] ?></td>
            <td><h3>₹</h3><?php echo $row['price'] ?></td>
            <td><img height="50px" width="60px" src="<?php echo $row['prop_images'];?>"  ></td>
            <td><a href="property-list.php?delete_id=<?php echo $row["pid"]; ?>" onClick='return checkdelete()'>Delete</a></td>
            <td><a href="property-update.php?pid=<?php echo $row["pid"]; ?>">Update</a></td>

        </tr>
        
        <?php
			}

        
			?>
      
      
    </table>   
    <br>  
    <div class="pagination">
    <h3 id="page-link">
    <?php
         //display the link of the pages in URL  
    for($page = 1; $page<= $number_of_page; $page++) {  
      echo '<a href = "property-list.php?page=' . $page . '"> ' . $page . ' -</a>';  
     }
    ?>
     </h3>
     </div>
  </div> 

</body>
</html>

<?php
    
}
else{
    header("Location: index.php");
    exit();
}
?>

<script LANGUAGE="JavaScript">

function checkdelete()
{
  return confirm('Are you sure to delete this record?');
}

</script>