<?php

include('connection.php');


if (!empty($_POST)){    
//print_r($_POST);die;

    $j = 0;     
$target_path = "uploads/";   
for ($i = 0; $i < count($_FILES['file']['name']); $i++) {

$validextensions = array("jpeg", "jpg", "png");     
$ext = explode('.', basename($_FILES['file']['name'][$i]));   
$file_extension = end($ext); 
$target_path = $target_path . md5(uniqid()) . "." . $ext[count($ext) - 1];    
$j = $j + 1;      
if (($_FILES["file"]["size"][$i] < 1000000)     
&& in_array($file_extension, $validextensions)) {
if (move_uploaded_file($_FILES['file']['tmp_name'][$i], $target_path)) {

 $j. ').<span class="success">Image uploaded successfully!.</span><br/><br/>' ;
} else {     
 $j. ').<span class="error">please try again!.</span><br/><br/>';
}
} else {     
 $j. ').<span class="error">***Image size must be less than 1mb and only jpeg, jpg, png files are allowed.***</span><br/><br/>';
}
}



    //echo 12345; die;

    $success=$error_ukn=$pro_err=$loc_err=$bed_err=$bath_err=$img_err="";

   

    $id = $_POST['id'];
    $propertyfor = $_POST['propertyfor'];
    $location = $_POST['location'];
    $bed = $_POST['bed'];
    $bath = $_POST['bath'];
    $price = $_POST['price'];

    if(empty($propertyfor)){
        $pro_err= "<span class='error'>Please enter your name.</span>";
        
    }
    else if(empty($location))
    {
        $loc_err= "<span class='error'> Please enter property location. </span>";
    }
    else if(empty($bed))
    {
        $bed_err = "<span class= 'error'> Please enter no. of bed. </span>";
    }
    else if (empty($bath))
    {
        $bath_err = "<span class='error'> Please enter no. of bath. </span>";
    }
    else if(empty($target_path))
    {
        $img_err = "<span class='error'> Please upload property images. </span>";
    }
    else if(empty($price))
    {
        $price_err = "<span class='error'> Please enter property price. </span>";
    }
    else{
        //echo 1235;die;

    $sql= "INSERT INTO `users_details`(`id`, `pid`, `propertyfor`, `location`, `bed`, `bath`, `prop_images`, `price`) 
    VALUES ('$id','','$propertyfor','$location','$bed','$bath','$target_path','$price')";

    
     
    $result = mysqli_query($conn, $sql);

    
    print_r($sql);die;

    if($result){
        //echo 1234;die;
        echo "ok";
    }
    else{
       echo "error";
     
    }

    

    }

}
else
{
    header('location:add-property.php');
    exit();
}




?>